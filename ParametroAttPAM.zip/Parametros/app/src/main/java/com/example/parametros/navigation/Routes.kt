package com.example.parametros.navigation

object Routes {
    const val LOGIN_ROUTE = "login"
    const val HOME_ROUTE = "home/{user}"

}