package com.example.parametros.data

val jonatas = User(
    userId = "Jonatas",
    name = "Jonatas",
    avatarUrl = null,
    age = 17,
    score = 60,
    registerDate = "20/10/2007",
    email = "jonatas.palmieri@etec.sp.gov.br",
    bio = "Estou criando um aplicativo com passagens de parâmetros"
)



val  jose = User(
    userId = "Jose",
    name = "Jose",
    avatarUrl = null,
    age = 24,
    score = 50,
    registerDate = "10/10/2010",
    email = "jose.da.silva@gmail.com",
    bio = "Estou criando um aplicativo com passagens de parâmetros"
)

fun getUserData(userName: String): User? {
    return if (userName == "Jose") {
        jose
    } else if (userName == "Jonatas") {
        jonatas
    } else {
        null
    }
}
