package com.example.parametros.navigation

const val USER = "user"